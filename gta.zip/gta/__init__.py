from .gta import GTA


def setup(bot):
    bot.add_cog(GTA(bot))