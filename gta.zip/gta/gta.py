import asyncio
import discord
import pathlib
from redbot.core import Config, checks, commands
from redbot.core.bot import Red
from redbot.core.data_manager import cog_data_path
from redbot.core.utils.chat_formatting import pagify, box
import datetime

def role_check(roles, user):
    for i in range(len(user.roles)):
        if user.roles[i].name in roles:
            return True
    return False

class GTA(commands.Cog):
    "Cog made for GTA."

    def __init__(self, bot: Red):
        self.bot = bot
        self.data = Config.get_conf(self, identifier=21506343935631, force_registration=True)
        default_guild = {
            "warrant_channel": None,
            "apb_channel": None,
            "book_channel": None
        } 
        default_member = {
            "log_bans": {
                "latest_date": None,
                "reasons": {}},
            "log_strikes": {
                "reasons": {},
                "no_of_strikes": 0},
            "book_date": None,
            "offense_code": None,
            "arresting_officer": None,
            "additional": None,
            "suspects_name": None,
            "suspects_dob": None,
            "term": None,
            "charge": None,
            "desc": None
        }
        self.data.register_member(**default_member)
        self.data.register_guild(**default_guild)
            
    @commands.command()
    async def logban(self, ctx, user: discord.Member, reason: str, expiration: str):
        """Add the information about the ban into the log."""
        if role_check(["Staff"], ctx.author):
            try:
                datetime.datetime.strptime(expiration, "%d/%m/%Y")
                expiration_date = expiration
                todays_date = datetime.datetime.utcnow().strftime("%d/%m/%Y | %H:%M:%S UTC")
            except ValueError:
                await ctx.send("Incorrect date format, please use ``DD/MM/YYYY`` as the date format! Example: ``26/04/2019``.")
                return
            
            try:
                reasons_dict = await self.data.member(user).log_bans.get_raw("reasons")
                if reason in reasons_dict:
                    await ctx.send("{}, is already banned for this reason!".format(user))
                    return
            except:
                pass
            
            await self.data.member(user).log_bans.reasons.set_raw(reason, value={"expiration_date": expiration_date})
            await self.data.member(user).log_bans.set_raw("latest_date", value=todays_date)
            await ctx.send("Successfully added the user to logban!")
              
    @commands.command()
    async def bans(self, ctx, user: discord.Member):
        """View bans of a user."""
        if role_check(["Staff"], ctx.author):
            todays_date = await self.data.member(user).log_bans.get_raw("latest_date")
            reasons_var = await self.data.member(user).log_bans.get_raw("reasons")
            i = 1
            msg = ""
            for reason in reasons_var:
                expiration_date = await self.data.member(user).log_bans.reasons.get_raw(reason, "expiration_date")
                msg+= "{}- {} ``({})``\n".format(i, reason, expiration_date)
                i = i + 1
            embed=discord.Embed(title="Reasons", description=msg, colour=0xff0000)
            embed.set_author(name=user, icon_url=user.avatar_url)
            embed.set_footer(text=todays_date)
            await ctx.send(embed=embed)
        
    @commands.command()
    async def recentbans(self, ctx, amount: int):
        """View x amount of recent bans"""
        if role_check(["Staff"], ctx.author):
            try:
                no_of_members = len(await self.data.all_members(ctx.guild))
                if amount > no_of_members:
                    await ctx.send("Invalid amount! There are only {} members banned!".format(no_of_members))
                    return
                i = 0
                n = 1
                reasons_msg = ""
                embed=discord.Embed(colour=0xff0000)
                for userid in await self.data.all_members(ctx.guild):
                    user = ctx.guild.get_member(userid)
                    todays_date = await self.data.member(user).log_bans.get_raw("latest_date")
                    reasons_var = await self.data.member(user).log_bans.get_raw("reasons")
                    if not reasons_var:
                        expiration_date = None
                        reasons_msg = None
                    else:
                        pass
                    i = i + 1
                    for reason in reasons_var:
                        expiration_date = await self.data.member(user).log_bans.reasons.get_raw(reason, "expiration_date")
                        reasons_msg+= "{}- {} ``({})``\n".format(n, reason, expiration_date)
                        n = n + 1
                    embed.add_field(name="{}- {}'s Reasons".format(i, user.name), value=reasons_msg, inline=False)
                    n = 1
                    reasons_msg = ""
                    if i == amount:
                        embed.set_footer(text=todays_date)
                        await ctx.send(embed=embed)
                        return
            except:
                pass
        
    @commands.command()
    async def warrant(self, ctx, user: discord.Member, badge: str, player_name: str, crime_committed: str, instructions: str):
        """Reposts as an embed."""
        if role_check(["Police"], ctx.author):
            channel = ctx.guild.get_channel(await self.data.guild(ctx.guild).warrant_channel())
            embed=discord.Embed(colour=0x008aff)
            embed.set_author(name=user, icon_url=user.avatar_url)
            embed.add_field(name="Badge", value=badge, inline=False)
            embed.add_field(name="Player Name", value=player_name, inline=False)
            embed.add_field(name="Crime Committed", value=crime_committed, inline=False)
            embed.add_field(name="Instructions", value=instructions, inline=False)
            await channel.send(embed=embed)
            await ctx.send("Successfully sent the message in <#{}>".format(channel.id))
        
    @commands.command()
    async def apb(self, ctx, player_description: str, crime_committed: str):
        """Reposts as an embed."""
        if role_check(["Police"], ctx.author):
            channel = ctx.guild.get_channel(await self.data.guild(ctx.guild).apb_channel())
            embed=discord.Embed(colour=0x00ff72)
            embed.add_field(name="Player Description", value=player_description, inline=False)
            embed.add_field(name="Crime Committed", value=crime_committed, inline=False)
            await channel.send(embed=embed)
            await ctx.send("Successfully sent the message in <#{}>".format(channel.id))
        
    @commands.command()
    async def book(self, ctx, user: discord.Member, date: str, offense_code: str, arresting_officer: str, suspects_name: str, suspects_dob: str, term: str, charge: str, desc: str, additional: str=None):
        """Reposts as an embed, and save the information for a user"""
        if role_check(["Police"], ctx.author):
            try:
                datetime.datetime.strptime(date, "%d/%m/%Y")
                date_var = date
            except ValueError:
                await ctx.send("Incorrect date format, please use ``DD/MM/YYYY`` as the date format! Example: ``26/04/2019``.")
                return
            channel = ctx.guild.get_channel(await self.data.guild(ctx.guild).book_channel())
            embed=discord.Embed(colour=0xff0088)
            embed.set_author(name=user, icon_url=user.avatar_url)
            embed.add_field(name="Date", value=date_var)
            embed.add_field(name="Offense Code", value=offense_code, inline=False)
            embed.add_field(name="Arresting Officer", value=arresting_officer, inline=False)
            embed.add_field(name="Suspect's Name", value=suspects_name, inline=False)
            embed.add_field(name="Suspect's DOB", value=suspects_dob, inline=False)
            embed.add_field(name="Term", value=term, inline=False)
            embed.add_field(name="Charge", value=charge, inline=False)
            embed.add_field(name="Desc", value=desc, inline=False)
            if additional:
                embed.add_field(name="Additional", value=additional, inline=False)
                await self.data.member(user).additional.set(additional)
            try:
                await self.data.member(user).book_date.set(date_var)
                await self.data.member(user).offense_code.set(offense_code)
                await self.data.member(user).arresting_officer.set(arresting_officer)
                await self.data.member(user).suspects_name.set(suspects_name)
                await self.data.member(user).suspects_dob.set(suspects_dob)
                await self.data.member(user).term.set(term)
                await self.data.member(user).charge.set(charge)
                await self.data.member(user).desc.set(desc)
            except:
                await ctx.send("An error occured while saving!")
                return
            await channel.send(embed=embed)
            await ctx.send("Successfully sent the message in <#{}>".format(channel.id))
    
    @commands.group()
    async def setchannel(self, ctx):
        if role_check(["Bot Admin"], ctx.author):
            if ctx.invoked_subcommand is None:
                pass 
    
    @setchannel.command(name="warrant")
    async def _warrant(self, ctx, channel: discord.TextChannel):
        """Set the text channel for warrant."""
        if role_check(["Bot Admin"], ctx.author):
            if not channel:
                pass
            elif channel:
                await self.data.guild(ctx.guild).warrant_channel.set(channel.id)
                await ctx.send("Successfully set the warrant channel to <#{}>".format(channel.id))
            else:
                await ctx.send("An error occured, please try again!")
                
    @setchannel.command(name="apb")
    async def _apb(self, ctx, channel: discord.TextChannel):
        """Set the text channel for APB."""
        if role_check(["Bot Admin"], ctx.author):
            if not channel:
                pass
            elif channel:
                await self.data.guild(ctx.guild).apb_channel.set(channel.id)
                await ctx.send("Successfully set the APB channel to <#{}>".format(channel.id))
            else:
                await ctx.send("An error occured, please try again!")

    @setchannel.command(name="book")
    async def _book(self, ctx, channel: discord.TextChannel):
        """Set the text channel for book."""
        if role_check(["Bot Admin"], ctx.author):
            if not channel:
                pass
            elif channel:
                await self.data.guild(ctx.guild).book_channel.set(channel.id)
                await ctx.send("Successfully set the book channel to <#{}>".format(channel.id))
            else:
                await ctx.send("An error occured, please try again!")
            
    @commands.command()
    async def strike(self, ctx, user: discord.Member, reason: str, expiration: str):
        """Strike a user."""
        if role_check(["Staff"], ctx.author):
            try:
                datetime.datetime.strptime(expiration, "%d/%m/%Y")
                expiration_date = expiration
            except ValueError:
                await ctx.send("Incorrect date format, please use ``DD/MM/YYYY`` as the date format! Example: ``26/04/2019``.")
                return
            
            try:
                reasons_dict = await self.data.member(user).log_strikes.get_raw("reasons")
                if reason in reasons_dict:
                    await ctx.send("{}, have already received a strike for this reason!".format(user))
                    return
            except:
                pass
            
            await self.data.member(user).log_strikes.reasons.set_raw(reason, value={"expiration_date": expiration_date})
            strikes_count = await self.data.member(user).log_strikes.get_raw("no_of_strikes")
            await self.data.member(user).log_strikes.set_raw("no_of_strikes", value=strikes_count + 1)
            
            embed=discord.Embed(description="{}, got a strike!".format(user.mention), colour=0xfb5000)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Expiration Date", value=expiration_date, inline=False)
            embed.add_field(name="Total Number of Strikes", value=await self.data.member(user).log_strikes.get_raw("no_of_strikes"), inline=False)
            embed.set_author(name="Strike!", icon_url=user.avatar_url)
            await ctx.send(embed=embed)
            try:
                await user.send(embed=embed)
                await ctx.send("Successfully sent the message to the user!")
            except:
                await ctx.send("Failed to send message to this user!")
        
    @commands.command()
    async def strikes(self, ctx, user: discord.Member):
        """Show all the strikes for a user"""
        if role_check(["Staff"], ctx.author):
            reasons_dict = await self.data.member(user).log_strikes.get_raw("reasons")
            i = 1
            msg = ""
            for reason in reasons_dict:
                expiration_date = await self.data.member(user).log_strikes.reasons.get_raw(reason, "expiration_date")
                msg+= "{}- {} ``({})``\n".format(i, reason, expiration_date)
                i = i + 1
            embed=discord.Embed(title="Reasons", description=msg, colour=0xfb5000)
            embed.add_field(name="Total Number of Strikes", value=await self.data.member(user).log_strikes.get_raw("no_of_strikes"), inline=False)
            embed.set_author(name=user, icon_url=user.avatar_url)
            await ctx.send(embed=embed)
        
    @commands.command()
    async def recentstrikes(self, ctx, amount: int):
        """Show recent strikes"""
        if role_check(["Staff"], ctx.author):
            try:
                no_of_members = len(await self.data.all_members(ctx.guild))
                if amount > no_of_members:
                    await ctx.send("Invalid amount! There are only {} members with strikes!".format(no_of_members))
                    return
                i = 0
                n = 1
                reasons_msg = ""
                embed=discord.Embed(colour=0xfb5000)
                for userid in await self.data.all_members(ctx.guild):
                    user = ctx.guild.get_member(userid)
                    reasons_dict = await self.data.member(user).log_strikes.get_raw("reasons")
                    if not reasons_dict:
                        strikes_count = 0
                        expiration_date = None
                        reasons_msg = None
                    else:
                        pass
                    i = i + 1
                    for reason in reasons_dict:
                        strikes_count = await self.data.member(user).log_strikes.get_raw("no_of_strikes")
                        expiration_date = await self.data.member(user).log_strikes.reasons.get_raw(reason, "expiration_date")
                        reasons_msg+= "{}- {} ``({})``\n".format(n, reason, expiration_date)
                        n = n + 1
                    embed.add_field(name="{}- {}'s Reasons".format(i, user.name), value="{}\n**Strikes Count:** {}".format(reasons_msg, strikes_count), inline=False)
                    n = 1
                    reasons_msg = ""                
                    if i == amount:
                        await ctx.send(embed=embed)
                        return
            except:
                pass